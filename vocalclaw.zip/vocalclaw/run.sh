#!/bin/bash
# VocalClaw - One command startup
set -e

echo ""
echo "  ⚡ VocalClaw — Multi-Agent Voice AI"
echo "  ElevenLabs × AirClaw"
echo ""

# Check Python
python3 --version >/dev/null 2>&1 || { echo "❌ Python 3 required"; exit 1; }

# Install deps if needed
echo "▸ Checking dependencies..."
pip install -q -r requirements.txt

# Check if AirClaw is running
echo "▸ Checking AirClaw local LLM..."
AIRCLAW_URL=${AIRCLAW_URL:-"http://localhost:4096"}

if curl -sf "$AIRCLAW_URL/v1/models" >/dev/null 2>&1; then
  echo "  ✅ AirClaw is running at $AIRCLAW_URL"
else
  echo ""
  echo "  ⚠️  AirClaw not detected at $AIRCLAW_URL"
  echo "  Run this in another terminal:"
  echo ""
  echo "    pip install airclaw && airclaw start"
  echo ""
  echo "  (VocalClaw will still start — agents will prompt you to start AirClaw)"
  echo ""
fi

echo ""
echo "  🚀 Starting VocalClaw on http://localhost:8080"
echo "  Open your browser and hold the microphone button to talk"
echo ""

uvicorn server:app --host 0.0.0.0 --port 8080 --reload
